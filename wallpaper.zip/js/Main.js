function livelyPropertyListener(name, val){
    switch(name){
        case "baseColor":{
            baseColor = val;
        }break;
        case "cellSize":{
            cellSize = val;
        }
            
    }
}

function livelyAudioListener(audioArray)
{
    
}

let baseColor = getColor(100, 100, 100);
let cellSize = 50;
let offsetStrength = 1000;
let bgColor = 'white';
let noiseScale = 1;
let framerate = 60;
let speed = 4000;
let colorSpeed = 4000;
let lineWidth = 1;
let seeTrough = false;

let canvas = new Canvas(document.getElementById('canvas'));

canvas.setWidth(window.innerWidth);
canvas.setHeight(window.innerHeight);

canvas.setLineWidth(lineWidth);

setInterval(function(){draw();}, 1000 / framerate);

var positions = [];

function draw(){
    const start = performance.now();

    canvas.setLineWidth(lineWidth);
    canvas.drawRect(new Vector2(0, 0), new Vector2(10000, 10000), bgColor);


    for (let x = 0; x < Math.ceil(window.innerWidth / cellSize + 1) * 2; x++) {
        positions[x] = [];
        for (let y = 0; y < Math.ceil(window.innerHeight / cellSize + 1) * 2; y++) {
            const noisePos = perlin.get(x / Math.ceil(window.innerWidth / cellSize + 1) * noiseScale + (Date.now() / speed), y / Math.ceil(window.innerHeight / cellSize + 1) * noiseScale + (Date.now() / speed)) * offsetStrength;
            const pos = new Vector2(x * cellSize + noisePos, y * cellSize + noisePos);
            positions[x][y] = pos;
        }
    }
    
    for (let x = 0; x < positions.length - 1; x++) {
        for (let y = 0; y < positions[0].length - 1; y++) {

            const a = new Vector2(positions[x][y].x - 350, positions[x][y].y - 350)
            const b = new Vector2(positions[x + 1][y].x - 350, positions[x + 1][y].y - 350);
            const c = new Vector2(positions[x + 1][y + 1].x - 350, positions[x + 1][y + 1].y - 350);
            const d = new Vector2(positions[x][y + 1].x - 350, positions[x][y + 1].y - 350);

            const color = getRainbowColor(Date.now() / colorSpeed + x * y * 10);
            if(seeTrough == false){
                canvas.drawFourCornerFill(a, b, c, d, bgColor);
            }
            
            canvas.drawFourCornerStroke(a, b, c, d, color);
        }
    }

    const end = performance.now();
    if((end - start) > 1000 / framerate){
        console.warn("Can't keep up! Target frametime: " + (1000 / framerate) + " Gotten Frametime: " + (end - start));
        
    }
    
}

function getColor(r, g, b){
    return 'rgb(' + r + ',' + g + ',' + b + ')';
}


function getRainbowColor(position) {
    //Calculating Normalized position
    var normalizedPosition = position % 1;
    if (normalizedPosition < 0) {
      normalizedPosition += 1;
    }
  
    //Calculating r, g, b components
    var red = Math.round(Math.sin(normalizedPosition * Math.PI * 2 + 0) * 127 + 128);
    var green = Math.round(Math.sin(normalizedPosition * Math.PI * 2 + (2 * Math.PI / 3)) * 127 + 128);
    var blue = Math.round(Math.sin(normalizedPosition * Math.PI * 2 + (4 * Math.PI / 3)) * 127 + 128);
  
    //Generating Color String
    var color = 'rgb(' + red + ', ' + green + ', ' + blue + ')';
  
    //Returning Color
    return color;
  }